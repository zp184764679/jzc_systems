# services/invoice_ocr_service.py
# -*- coding: utf-8 -*-
"""
发票OCR识别服务
支持PaddleOCR本地识别 + 百度云API备用
"""
import os
import re
import logging
from datetime import datetime
from typing import Dict, Optional, Tuple
import base64

logger = logging.getLogger(__name__)


class InvoiceOCRService:
    """发票OCR识别服务"""

    def __init__(self):
        self.ocr_engine = None
        self.use_cloud_api = os.getenv('USE_BAIDU_OCR', 'false').lower() == 'true'

        # 尝试初始化PaddleOCR
        if not self.use_cloud_api:
            try:
                from paddleocr import PaddleOCR
                # PaddleOCR 3.3.1+ 简化参数
                self.ocr_engine = PaddleOCR(lang='ch')
                logger.info("✅ PaddleOCR初始化成功")
            except ImportError:
                logger.warning("⚠️ PaddleOCR未安装，将使用简单文本提取")
                self.ocr_engine = None
            except Exception as e:
                logger.error(f"❌ PaddleOCR初始化失败: {str(e)}")
                self.ocr_engine = None

    def extract_invoice_info(self, file_path: str) -> Dict:
        """
        从发票文件中提取信息

        Args:
            file_path: 发票文件路径

        Returns:
            {
                "success": bool,
                "invoice_number": str,
                "amount": float,
                "date": str,
                "confidence": float,
                "raw_text": str
            }
        """
        try:
            if self.use_cloud_api:
                return self._extract_with_baidu_api(file_path)
            elif self.ocr_engine:
                return self._extract_with_paddleocr(file_path)
            else:
                return self._extract_with_fallback(file_path)
        except Exception as e:
            logger.error(f"❌ OCR识别失败: {str(e)}")
            return {
                "success": False,
                "error": f"识别失败: {str(e)}",
                "invoice_number": "",
                "amount": 0.0,
                "date": "",
                "confidence": 0.0,
                "raw_text": ""
            }

    def _extract_with_paddleocr(self, file_path: str) -> Dict:
        """使用PaddleOCR识别（支持3.3.1+ OCRResult格式）"""
        try:
            result = self.ocr_engine.ocr(file_path)

            # 调试：打印result结构
            logger.info(f"🔍 OCR原始结果类型: {type(result)}")
            if result:
                logger.info(f"🔍 OCR结果长度: {len(result)}")
                if len(result) > 0:
                    logger.info(f"🔍 OCR结果[0]类型: {type(result[0])}")

            # 检查result是否为空
            if not result or len(result) == 0:
                logger.warning("⚠️ OCR未识别到任何文本")
                return {
                    "success": False,
                    "error": "未识别到文本",
                    "invoice_number": "",
                    "amount": 0.0,
                    "date": "",
                    "confidence": 0.0,
                    "raw_text": ""
                }

            # PaddleOCR 3.3.1+ 返回OCRResult对象
            ocr_result = result[0]

            # 提取识别文本
            all_text = []
            avg_confidence = 0.0

            # 检查是否是OCRResult对象（有json属性）
            if hasattr(ocr_result, 'json'):
                # 新格式：OCRResult对象
                result_data = ocr_result.json if isinstance(ocr_result.json, dict) else ocr_result

                # 从rec_texts字段获取识别文本
                if 'rec_texts' in result_data:
                    all_text = result_data['rec_texts']
                    logger.info(f"✅ 从OCRResult获取到 {len(all_text)} 行文本")

                    # 获取平均置信度
                    if 'rec_scores' in result_data and result_data['rec_scores']:
                        avg_confidence = sum(result_data['rec_scores']) / len(result_data['rec_scores'])
                        logger.info(f"✅ 平均置信度: {avg_confidence:.2f}")
                else:
                    logger.warning("⚠️ OCRResult中未找到rec_texts字段")
            else:
                # 旧格式：兼容老版本的列表格式
                logger.info("⚠️ 检测到旧版OCR格式，使用兼容模式")
                for idx, line in enumerate(ocr_result):
                    try:
                        if isinstance(line, (list, tuple)) and len(line) >= 2:
                            text_data = line[1]
                            if isinstance(text_data, (list, tuple)) and len(text_data) >= 1:
                                text = str(text_data[0])
                                all_text.append(text)
                    except Exception as line_error:
                        logger.warning(f"⚠️ 处理第{idx}行出错: {line_error}")
                        continue

            # 合并所有文本
            full_text = "\n".join(all_text)
            logger.info(f"📝 OCR识别文本({len(all_text)}行):\n{full_text[:500]}")  # 只显示前500字符

            if not full_text.strip():
                logger.warning("⚠️ OCR识别结果为空")
                return {
                    "success": False,
                    "error": "识别结果为空",
                    "invoice_number": "",
                    "amount": 0.0,
                    "date": "",
                    "confidence": 0.0,
                    "raw_text": ""
                }

            # 智能提取发票信息
            invoice_info = self._parse_invoice_text(full_text)
            invoice_info["success"] = True
            invoice_info["raw_text"] = full_text
            invoice_info["confidence"] = avg_confidence if avg_confidence > 0 else 0.85

            return invoice_info

        except Exception as e:
            logger.error(f"❌ PaddleOCR识别失败: {str(e)}")
            import traceback
            logger.error(f"详细错误: {traceback.format_exc()}")
            return {
                "success": False,
                "error": str(e),
                "invoice_number": "",
                "amount": 0.0,
                "date": "",
                "confidence": 0.0,
                "raw_text": ""
            }

    def _extract_with_baidu_api(self, file_path: str) -> Dict:
        """使用百度云API识别（需要配置API Key）"""
        try:
            from aip import AipOcr

            app_id = os.getenv('BAIDU_OCR_APP_ID')
            api_key = os.getenv('BAIDU_OCR_API_KEY')
            secret_key = os.getenv('BAIDU_OCR_SECRET_KEY')

            if not all([app_id, api_key, secret_key]):
                raise ValueError("百度OCR API配置不完整")

            client = AipOcr(app_id, api_key, secret_key)

            # 读取图片
            with open(file_path, 'rb') as f:
                image = f.read()

            # 调用增值税发票识别
            result = client.vatInvoice(image)

            if 'words_result' in result:
                words = result['words_result']
                return {
                    "success": True,
                    "invoice_number": words.get('InvoiceNum', ''),
                    "amount": self._parse_amount(words.get('AmountInFiguers', '')),
                    "date": self._parse_date(words.get('InvoiceDate', '')),
                    "confidence": 0.95,
                    "raw_text": str(words)
                }
            else:
                raise ValueError("API返回格式错误")

        except Exception as e:
            logger.error(f"❌ 百度OCR API调用失败: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "invoice_number": "",
                "amount": 0.0,
                "date": "",
                "confidence": 0.0,
                "raw_text": ""
            }

    def _extract_with_fallback(self, file_path: str) -> Dict:
        """简单文本提取（fallback方案）"""
        logger.warning("⚠️ 使用fallback方案，识别准确率较低")
        return {
            "success": False,
            "error": "OCR引擎未安装",
            "invoice_number": "",
            "amount": 0.0,
            "date": "",
            "confidence": 0.0,
            "raw_text": "请安装 paddlepaddle 和 paddleocr"
        }

    def _parse_invoice_text(self, text: str) -> Dict:
        """
        智能解析发票文本，提取关键信息

        支持多种发票格式：
        - 增值税专用发票
        - 增值税普通发票
        - 电子发票
        """
        invoice_info = {
            "invoice_code": "",
            "invoice_number": "",
            "invoice_date": "",
            "amount": 0.0,
            "date": "",  # 保持向后兼容
            "buyer_name": "",
            "buyer_tax_id": "",
            "seller_name": "",
            "seller_tax_id": "",
            "amount_before_tax": 0.0,
            "tax_amount": 0.0,
            "total_amount": 0.0,
            "remark": ""
        }

        lines = text.split('\n')

        # 1. 提取发票代码
        invoice_code = self._extract_invoice_code(text)
        if invoice_code:
            invoice_info["invoice_code"] = invoice_code

        # 2. 提取发票号码
        invoice_number = self._extract_invoice_number(text)
        if invoice_number:
            invoice_info["invoice_number"] = invoice_number

        # 3. 提取日期
        date_str = self._extract_date(text)
        if date_str:
            invoice_info["date"] = date_str
            invoice_info["invoice_date"] = date_str

        # 4. 提取购买方信息
        buyer_name = self._extract_buyer_name(text)
        if buyer_name:
            invoice_info["buyer_name"] = buyer_name

        buyer_tax_id = self._extract_buyer_tax_id(text)
        if buyer_tax_id:
            invoice_info["buyer_tax_id"] = buyer_tax_id

        # 5. 提取销售方信息
        seller_name = self._extract_seller_name(text)
        if seller_name:
            invoice_info["seller_name"] = seller_name

        seller_tax_id = self._extract_seller_tax_id(text)
        if seller_tax_id:
            invoice_info["seller_tax_id"] = seller_tax_id

        # 6. 提取金额信息
        amount_before_tax = self._extract_amount_before_tax(text)
        if amount_before_tax:
            invoice_info["amount_before_tax"] = amount_before_tax

        tax_amount = self._extract_tax_amount(text)
        if tax_amount:
            invoice_info["tax_amount"] = tax_amount

        total_amount = self._extract_amount(text)
        if total_amount:
            invoice_info["amount"] = total_amount
            invoice_info["total_amount"] = total_amount

        # 7. 提取备注
        remark = self._extract_remark(text)
        if remark:
            invoice_info["remark"] = remark

        return invoice_info

    def _extract_invoice_number(self, text: str) -> str:
        """提取发票号码"""
        patterns = [
            r'发票号码[:\s：]*([0-9]{8,12})',
            r'No[:\s：]*([0-9]{8,12})',
            r'invoice\s*no[:\s：]*([0-9]{8,12})',
            r'票号[:\s：]*([0-9]{8,12})',
            r'([0-9]{8,12})',  # 最后尝试匹配纯数字
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                number = match.group(1)
                # 验证：发票号通常是8-12位数字
                if 8 <= len(number) <= 12:
                    logger.info(f"✅ 识别到发票号: {number}")
                    return number

        return ""

    def _extract_amount(self, text: str) -> float:
        """提取金额"""
        patterns = [
            r'[合价金]额[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'小写[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'价税合计[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'total[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                amount_str = match.group(2).replace(',', '').replace(' ', '')
                try:
                    amount = float(amount_str)
                    if amount > 0:
                        logger.info(f"✅ 识别到金额: {amount}")
                        return amount
                except ValueError:
                    continue

        return 0.0

    def _extract_date(self, text: str) -> str:
        """提取日期"""
        patterns = [
            r'开票日期[:\s：]*(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})',
            r'date[:\s：]*(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})',
            r'(\d{4})[年\-/](\d{1,2})[月\-/](\d{1,2})[日]?',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                year = match.group(1)
                month = match.group(2).zfill(2)
                day = match.group(3).zfill(2)
                date_str = f"{year}-{month}-{day}"

                # 验证日期有效性
                try:
                    datetime.strptime(date_str, '%Y-%m-%d')
                    logger.info(f"✅ 识别到日期: {date_str}")
                    return date_str
                except ValueError:
                    continue

        return ""

    def _parse_amount(self, amount_str: str) -> float:
        """解析金额字符串"""
        if not amount_str:
            return 0.0
        try:
            return float(amount_str.replace(',', '').replace(' ', ''))
        except:
            return 0.0

    def _parse_date(self, date_str: str) -> str:
        """解析日期字符串"""
        if not date_str:
            return ""

        # 尝试多种日期格式
        formats = ['%Y%m%d', '%Y-%m-%d', '%Y/%m/%d', '%Y年%m月%d日']
        for fmt in formats:
            try:
                dt = datetime.strptime(date_str, fmt)
                return dt.strftime('%Y-%m-%d')
            except:
                continue
        return date_str

    def _extract_invoice_code(self, text: str) -> str:
        """提取发票代码（10或12位数字）"""
        patterns = [
            r'发票代码[:\s：]*([0-9]{10,12})',
            r'代码[:\s：]*([0-9]{10,12})',
            r'code[:\s：]*([0-9]{10,12})',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                code = match.group(1)
                if 10 <= len(code) <= 12:
                    logger.info(f"✅ 识别到发票代码: {code}")
                    return code
        return ""

    def _extract_buyer_name(self, text: str) -> str:
        """提取购买方名称"""
        patterns = [
            r'购买方[名称\s]*[:\s：]*([\u4e00-\u9fa5a-zA-Z0-9（）()]+)',
            r'买方[:\s：]*([\u4e00-\u9fa5a-zA-Z0-9（）()]+)',
            r'客户名称[:\s：]*([\u4e00-\u9fa5a-zA-Z0-9（）()]+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                if len(name) > 2:  # 至少3个字符
                    logger.info(f"✅ 识别到购买方名称: {name}")
                    return name
        return ""

    def _extract_buyer_tax_id(self, text: str) -> str:
        """提取购买方税号/统一社会信用代码"""
        patterns = [
            r'购买方.*?税号[:\s：]*([A-Z0-9]{15,20})',
            r'购买方.*?纳税人识别号[:\s：]*([A-Z0-9]{15,20})',
            r'购买方.*?统一社会信用代码[:\s：]*([A-Z0-9]{15,20})',
            r'税号[:\s：]*([A-Z0-9]{15,20})',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                tax_id = match.group(1).strip()
                if 15 <= len(tax_id) <= 20:
                    logger.info(f"✅ 识别到购买方税号: {tax_id}")
                    return tax_id
        return ""

    def _extract_seller_name(self, text: str) -> str:
        """提取销售方名称（供应商）"""
        patterns = [
            r'销售方[名称\s]*[:\s：]*([\u4e00-\u9fa5a-zA-Z0-9（）()]+)',
            r'卖方[:\s：]*([\u4e00-\u9fa5a-zA-Z0-9（）()]+)',
            r'供应商[:\s：]*([\u4e00-\u9fa5a-zA-Z0-9（）()]+)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                name = match.group(1).strip()
                if len(name) > 2:
                    logger.info(f"✅ 识别到销售方名称: {name}")
                    return name
        return ""

    def _extract_seller_tax_id(self, text: str) -> str:
        """提取销售方税号"""
        patterns = [
            r'销售方.*?税号[:\s：]*([A-Z0-9]{15,20})',
            r'销售方.*?纳税人识别号[:\s：]*([A-Z0-9]{15,20})',
            r'销售方.*?统一社会信用代码[:\s：]*([A-Z0-9]{15,20})',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                tax_id = match.group(1).strip()
                if 15 <= len(tax_id) <= 20:
                    logger.info(f"✅ 识别到销售方税号: {tax_id}")
                    return tax_id
        return ""

    def _extract_amount_before_tax(self, text: str) -> float:
        """提取不含税金额"""
        patterns = [
            r'金额合计[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'不含税金额[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'合计金额[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                amount_str = match.group(2).replace(',', '').replace(' ', '')
                try:
                    amount = float(amount_str)
                    if amount > 0:
                        logger.info(f"✅ 识别到不含税金额: {amount}")
                        return amount
                except ValueError:
                    continue
        return 0.0

    def _extract_tax_amount(self, text: str) -> float:
        """提取税额"""
        patterns = [
            r'税额合计[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'税额[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
            r'增值税额[:\s：]*(￥|¥|RMB)?\s*([0-9,]+\.?[0-9]*)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                amount_str = match.group(2).replace(',', '').replace(' ', '')
                try:
                    amount = float(amount_str)
                    if amount >= 0:  # 税额可以是0
                        logger.info(f"✅ 识别到税额: {amount}")
                        return amount
                except ValueError:
                    continue
        return 0.0

    def _extract_remark(self, text: str) -> str:
        """提取备注"""
        patterns = [
            r'备注[:\s：]*([\s\S]{1,200}?)(?=\n\n|\n[^\s]|$)',
            r'说明[:\s：]*([\s\S]{1,200}?)(?=\n\n|\n[^\s]|$)',
        ]

        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                remark = match.group(1).strip()
                if len(remark) > 0:
                    logger.info(f"✅ 识别到备注: {remark[:50]}...")
                    return remark
        return ""


# 全局单例
_ocr_service = None

def get_ocr_service() -> InvoiceOCRService:
    """获取OCR服务单例"""
    global _ocr_service
    if _ocr_service is None:
        _ocr_service = InvoiceOCRService()
    return _ocr_service

