# constants/departments.py
DEPARTMENTS = [
{"name": "生产部", "children": ["走心机", "磨床", "加工中心"]},
{"name": "采购部"},
{"name": "仓库"},
{"name": "品质"},
{"name": "财务"},
{"name": "行政"},
{"name": "研发"},
{"name": "销售"},
]