# models/pr_item.py
from sqlalchemy import ForeignKey, Integer, String, Text
from sqlalchemy.dialects.mysql import BIGINT, VARCHAR
from extensions import db
from sqlalchemy.orm import relationship

class PRItem(db.Model):
    __tablename__ = "pr_item"
    
    id = db.Column(BIGINT(unsigned=True), primary_key=True, autoincrement=True)
    pr_id = db.Column(BIGINT(unsigned=True), ForeignKey('pr.id'), nullable=False)
    name = db.Column(String(200), nullable=False)
    spec = db.Column(String(200), nullable=True)
    qty = db.Column(Integer, nullable=False, default=1)
    unit = db.Column(VARCHAR(50), nullable=True)
    remark = db.Column(Text, nullable=True)
    status = db.Column(VARCHAR(50), nullable=False, default="pending")  # 新增：状态字段
    classification = db.Column(VARCHAR(100), nullable=True)  # 新增：分类字段

    # 关联 PR 类 - 使用字符串引用避免循环导入
    pr = relationship("PR", back_populates="items")
    
    def __repr__(self):
        return f'<PRItem {self.id}: {self.name}>'