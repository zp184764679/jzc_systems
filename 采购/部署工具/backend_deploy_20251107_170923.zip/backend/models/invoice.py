# models/invoice.py
# -*- coding: utf-8 -*-
from sqlalchemy import String, DateTime, Numeric, ForeignKey, Index, Text
from sqlalchemy.dialects.mysql import BIGINT
from datetime import datetime
from extensions import db

class Invoice(db.Model):
    __tablename__ = 'invoices'
    __table_args__ = (
        Index('idx_invoices_supplier_id', 'supplier_id'),
        Index('idx_invoices_po_id', 'po_id'),
        Index('idx_invoices_quote_id', 'quote_id'),
        Index('idx_invoices_status', 'status'),
        Index('idx_invoices_created_at', 'created_at'),
    )

    id = db.Column(BIGINT(unsigned=True), primary_key=True, autoincrement=True)
    
    # 外键关系
    supplier_id = db.Column(BIGINT(unsigned=True), ForeignKey('suppliers.id', ondelete='CASCADE'), nullable=False)
    po_id = db.Column(BIGINT(unsigned=True), ForeignKey('purchase_orders.id', ondelete='CASCADE'), nullable=False)  # 关联PO
    quote_id = db.Column(BIGINT(unsigned=True), ForeignKey('supplier_quotes.id', ondelete='SET NULL'), nullable=True)
    
    # 发票信息
    invoice_code = db.Column(String(50), nullable=True)  # 发票代码（10-12位）
    invoice_number = db.Column(String(100), unique=True, nullable=False)  # 发票号码
    invoice_date = db.Column(DateTime, nullable=True)  # 开票日期

    # 购买方信息
    buyer_name = db.Column(String(255), nullable=True)  # 购买方名称
    buyer_tax_id = db.Column(String(50), nullable=True)  # 购买方纳税人识别号/统一社会信用代码

    # 销售方信息（供应商）
    seller_name = db.Column(String(255), nullable=True)  # 销售方名称
    seller_tax_id = db.Column(String(50), nullable=True)  # 销售方纳税人识别号

    # 金额信息
    amount_before_tax = db.Column(Numeric(12, 2), nullable=True)  # 金额合计（不含税）
    tax_amount = db.Column(Numeric(12, 2), nullable=True)  # 税额合计
    total_amount = db.Column(Numeric(12, 2), nullable=True)  # 价税合计
    amount = db.Column(Numeric(12, 2), nullable=False)  # 发票金额（兼容旧版，通常等于total_amount）
    currency = db.Column(String(10), default='CNY', nullable=False)  # 货币
    
    # 文件信息
    file_url = db.Column(Text, nullable=False)  # 文件地址/URL
    file_name = db.Column(String(255), nullable=True)  # 文件名
    file_type = db.Column(String(50), nullable=True)  # 文件类型（PDF、图片等）
    file_size = db.Column(String(20), nullable=True)  # 文件大小（MB/字节）
    
    # 备注信息
    description = db.Column(Text, nullable=True)  # 发票描述（向后兼容）
    remark = db.Column(Text, nullable=True)  # 备注说明（中国发票格式）
    
    # 审批状态
    status = db.Column(String(20), default='pending', nullable=False)
    # 可选值: pending(待审批) / approved(已批准) / rejected(已拒绝) / expired(已过期)
    
    approval_notes = db.Column(Text, nullable=True)  # 审批意见
    approved_by = db.Column(BIGINT(unsigned=True), nullable=True)  # 审批人ID
    approved_at = db.Column(DateTime, nullable=True)  # 审批时间
    
    # 时间戳
    created_at = db.Column(DateTime, default=datetime.utcnow)  # 创建时间
    uploaded_at = db.Column(DateTime, nullable=True)  # 上传时间
    updated_at = db.Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    expiry_date = db.Column(DateTime, nullable=True)  # 发票过期日期
    
    # 关系
    supplier = db.relationship('Supplier', backref='invoices', lazy=True)
    po = db.relationship('PurchaseOrder', backref='invoices', lazy=True)
    quote = db.relationship('SupplierQuote', backref='invoices', lazy=True)

    def __repr__(self):
        return f'<Invoice {self.invoice_number}>'

    def to_dict(self):
        return {
            'id': self.id,
            'invoice_code': self.invoice_code,
            'invoice_number': self.invoice_number,
            'supplier_id': self.supplier_id,
            'po_id': self.po_id,
            'quote_id': self.quote_id,
            'invoice_date': self.invoice_date.isoformat() if self.invoice_date else None,
            'buyer_name': self.buyer_name,
            'buyer_tax_id': self.buyer_tax_id,
            'seller_name': self.seller_name,
            'seller_tax_id': self.seller_tax_id,
            'amount_before_tax': float(self.amount_before_tax) if self.amount_before_tax else None,
            'tax_amount': float(self.tax_amount) if self.tax_amount else None,
            'total_amount': float(self.total_amount) if self.total_amount else None,
            'amount': float(self.amount) if self.amount else 0,
            'currency': self.currency,
            'file_url': self.file_url,
            'file_name': self.file_name,
            'file_type': self.file_type,
            'file_size': self.file_size,
            'description': self.description,
            'remark': self.remark,
            'status': self.status,
            'approval_notes': self.approval_notes,
            'approved_by': self.approved_by,
            'approved_at': self.approved_at.isoformat() if self.approved_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'uploaded_at': self.uploaded_at.isoformat() if self.uploaded_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'expiry_date': self.expiry_date.isoformat() if self.expiry_date else None,
            'supplier': {
                'id': self.supplier.id,
                'company_name': self.supplier.company_name,
                'code': self.supplier.code,
            } if self.supplier else None,
            'po': {
                'id': self.po.id,
                'po_number': self.po.po_number,
                'total_price': float(self.po.total_price),
                'status': self.po.status,
            } if self.po else None,
            'quote': {
                'id': self.quote.id,
                'quote_number': self.quote.quote_number,
                'item_name': self.quote.item_name,
            } if self.quote else None,
        }