# suppliers/helpers/file_handler.py
# 文件处理：Base64 → 文件 → URL
# -*- coding: utf-8 -*-
import base64
import os
import uuid
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# 文件配置
UPLOAD_FOLDER = os.getenv('UPLOAD_FOLDER', 'uploads')
ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx'}
MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB


def ensure_upload_folder():
    """确保上传文件夹存在"""
    Path(UPLOAD_FOLDER).mkdir(parents=True, exist_ok=True)


def allowed_file(filename):
    """检查文件类型是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def get_file_extension(filename):
    """获取文件扩展名"""
    if '.' in filename:
        return filename.rsplit('.', 1)[1].lower()
    return 'bin'


def generate_unique_filename(original_filename):
    """生成唯一的文件名"""
    ext = get_file_extension(original_filename)
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    return unique_name


def decode_base64_file(base64_string):
    """
    从Base64字符串解码文件
    
    返回: (bytes, 错误信息)
    """
    try:
        # 移除 data:image/png;base64, 等前缀
        if ',' in base64_string:
            base64_string = base64_string.split(',')[1]
        
        # 解码
        file_bytes = base64.b64decode(base64_string)
        
        # 检查文件大小
        if len(file_bytes) > MAX_FILE_SIZE:
            return None, f"文件大小超过限制 ({MAX_FILE_SIZE / 1024 / 1024}MB)"
        
        if len(file_bytes) == 0:
            return None, "解码后的文件为空"
        
        return file_bytes, None
    
    except Exception as e:
        logger.error(f"❌ Base64解码失败: {str(e)}")
        return None, f"Base64解码失败: {str(e)}"


def save_file_to_disk(file_bytes, filename):
    """
    将文件字节保存到磁盘
    
    返回: (文件路径, URL, 错误信息)
    """
    try:
        ensure_upload_folder()
        
        # 生成唯一文件名
        unique_filename = generate_unique_filename(filename)
        file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
        
        # 保存文件
        with open(file_path, 'wb') as f:
            f.write(file_bytes)
        
        # 生成URL（根据实际部署环境调整）
        file_url = f"/uploads/{unique_filename}"
        
        logger.info(f"✅ 文件已保存: {file_path}")
        
        return file_path, file_url, None
    
    except Exception as e:
        logger.error(f"❌ 文件保存失败: {str(e)}")
        return None, None, f"文件保存失败: {str(e)}"


def process_base64_file(base64_string, filename):
    """
    一键处理：Base64 → 解码 → 保存 → 返回URL
    
    返回: (file_url, 错误信息)
    """
    # 检查文件类型
    if not allowed_file(filename):
        return None, f"不支持的文件类型。允许: {', '.join(ALLOWED_EXTENSIONS)}"
    
    # 解码
    file_bytes, decode_err = decode_base64_file(base64_string)
    if decode_err:
        return None, decode_err
    
    # 保存
    file_path, file_url, save_err = save_file_to_disk(file_bytes, filename)
    if save_err:
        return None, save_err
    
    return file_url, None