# celery_app.py
# -*- coding: utf-8 -*-
from app import app                  # 你的 Flask 应用（确保 app.py 里创建了全局 app）
from extensions import init_celery, celery as _celery

# 绑定 Flask 上下文并加载环境变量中的 Celery 配置（Redis 等）
init_celery(app)

# 暴露给 celery -A 的实例名
celery = _celery
