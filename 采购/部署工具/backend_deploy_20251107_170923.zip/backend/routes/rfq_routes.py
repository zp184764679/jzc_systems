# routes/rfq_routes.py
# -*- coding: utf-8 -*-
from flask import Blueprint, request, jsonify
from extensions import db
from models.rfq import RFQ
from models.pr import PR
from models.supplier_quote import SupplierQuote
from models.rfq_notification_task import RFQNotificationTask
# ✅ 使用永久修复版服务（包含 send_rfq / create_supplier_quotes_for_routes 等）
from services.rfq_service import RFQService
import traceback
import json
from datetime import datetime

URL_PREFIX = '/api/v1/rfqs'

bp = Blueprint('rfq', __name__)  # 保持你的原定义（应用层应以 URL_PREFIX 注册）

rfq_service = RFQService()

@bp.before_request
def handle_preflight():
    """处理CORS预检请求"""
    if request.method == 'OPTIONS':
        return '', 200

def iso(dt):
    return dt.isoformat(timespec='seconds') if dt else None


@bp.route('/classify-suppliers', methods=['POST', 'OPTIONS'])
def route_suppliers():
    """
    根据分类结果匹配供应商（按品类）
    Request:
    {
      "groups": [
        { "category": "机械零部件/传动", "major_category": "机械零部件", "items": [...] }
      ]
    }
    Response:
    {
      "routes": [
        { "category": "机械零部件/传动", "supplierIds": [1, 2, 3] }
      ]
    }
    """
    if request.method == 'OPTIONS':
        return "", 204

    try:
        data = request.get_json() or {}
        groups = data.get("groups", [])

        if not groups:
            return jsonify({"error": "groups 不能为空"}), 400

        routes = []
        for group in groups:
            category = group.get("category")
            major_category = group.get("major_category")
            if not category:
                continue
            supplier_ids = rfq_service.match_suppliers_by_category(category, major_category)
            routes.append({
                "category": category,
                "supplierIds": supplier_ids
            })

        return jsonify({
            "routes": routes,
            "message": f"匹配成功，共 {sum(len(r['supplierIds']) for r in routes)} 个供应商"
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"匹配失败: {str(e)}"}), 500


@bp.route('', methods=['GET', 'POST', 'OPTIONS'])
def rfqs_endpoint():
    """
    GET: 查询RFQ（支持?pr_id=参数）
    POST: 创建RFQ（从PR）- 支持预分类结果
    自动：匹配 → 落库报价行 → 生成通知任务 → 标记 sent（永久修复）
    """
    if request.method == 'OPTIONS':
        return "", 204

    # GET请求：查询RFQ
    if request.method == 'GET':
        try:
            pr_id = request.args.get('pr_id')
            if pr_id:
                # 查询指定PR的RFQ
                rfqs = RFQ.query.filter_by(pr_id=int(pr_id)).all()
                return jsonify({
                    "items": [{
                        "id": rfq.id,
                        "pr_id": rfq.pr_id,
                        "status": rfq.status,
                        "note": rfq.note,
                        "created_at": iso(rfq.created_at),
                        "sent_at": iso(rfq.sent_at),
                        "items_count": len(rfq.items or [])
                    } for rfq in rfqs]
                }), 200
            else:
                # 查询所有RFQ
                rfqs = RFQ.query.order_by(RFQ.created_at.desc()).all()
                return jsonify({
                    "items": [{
                        "id": rfq.id,
                        "pr_id": rfq.pr_id,
                        "status": rfq.status,
                        "note": rfq.note,
                        "created_at": iso(rfq.created_at),
                        "sent_at": iso(rfq.sent_at),
                        "items_count": len(rfq.items or [])
                    } for rfq in rfqs]
                }), 200
        except Exception as e:
            traceback.print_exc()
            return jsonify({"error": f"查询失败: {str(e)}"}), 500

    # POST请求：创建RFQ
    try:
        data = request.get_json() or {}
        pr_id = data.get('pr_id')
        user_id = data.get('user_id') or 1  # 如果未提供，使用默认值1（系统用户）
        note = (data.get('note') or '').strip()
        classification_results = data.get('classification_results')
        skip_send = data.get('skip_send', False)  # 是否跳过发送（用于手动报价）

        if not pr_id:
            return jsonify({"error": "pr_id为必填"}), 400

        # 1) 校验 PR
        pr = PR.query.get(pr_id)
        if not pr:
            return jsonify({"error": "PR不存在"}), 404
        if pr.status != 'approved':
            return jsonify({"error": "只有已审批的PR才能创建RFQ"}), 400

        # 2) 创建 RFQ（可带预分类）
        if classification_results:
            rfq = rfq_service.create_rfq_from_pr_with_classification(
                pr, user_id, note, classification_results
            )
        else:
            rfq = rfq_service.create_rfq_from_pr(pr, user_id, note)

        # 3) 根据skip_send参数决定是否发送
        if skip_send:
            # 手动报价模式：只创建RFQ，不发送
            return jsonify({
                "id": rfq.id,
                "pr_id": rfq.pr_id,
                "status": rfq.status,
                "items": [{
                    "id": item.id,
                    "item_name": getattr(item, "item_name", None),
                    "item_spec": getattr(item, "item_spec", None),
                    "quantity": getattr(item, "quantity", None),
                    "unit": getattr(item, "unit", None),
                    "category": getattr(item, "category", None)
                } for item in (rfq.items or [])],
                "items_count": len(rfq.items or []),
                "message": "RFQ创建成功（待手动报价）"
            }), 201
        else:
            # 自动发送模式：匹配→落库报价行→任务→Celery→标记sent
            result = rfq_service.send_rfq(rfq, routes=None)  # routes=None表示自动匹配

            return jsonify({
                "id": rfq.id,
                "pr_id": rfq.pr_id,
                "status": rfq.status,                     # 预期 sent
                "items_count": len(rfq.items or []),
                "tasks_count": len(result.get("task_ids", [])),
                "created_quotes": result.get("created_quotes", 0),
                "total_suppliers": result.get("total_suppliers", 0),
                "message": "RFQ创建成功，已匹配并生成报价行与通知任务"
            }), 201

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({"error": f"创建失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>', methods=['GET', 'OPTIONS'])
def get_rfq(rfq_id):
    """获取RFQ详情（兼容新旧字段名）"""
    if request.method == 'OPTIONS':
        return "", 204

    try:
        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": "RFQ不存在"}), 404

        items_payload = []
        for item in (rfq.items or []):
            # 兼容 old/new 字段
            name = getattr(item, "item_name", None) or getattr(item, "name", None)
            spec = getattr(item, "item_spec", None) or getattr(item, "spec", None)
            qty = (getattr(item, "quantity", None) or getattr(item, "qty", None) or 1)
            try:
                qty = int(qty)
            except Exception:
                qty = 1

            items_payload.append({
                "id": item.id,
                "item_name": name or "",
                "item_spec": spec or "",
                "quantity": qty,
                "unit": getattr(item, "unit", None),
                "category": getattr(item, "category", None),
                "major_category": getattr(item, "major_category", None),
                "minor_category": getattr(item, "minor_category", None),
                "classification_source": getattr(item, "classification_source", None),
                "classification_score": json.loads(getattr(item, "classification_score", "") or "{}")
            })

        return jsonify({
            "id": rfq.id,
            "pr_id": rfq.pr_id,
            "status": rfq.status,
            "note": rfq.note,
            "created_at": iso(rfq.created_at),
            "sent_at": iso(rfq.sent_at),
            "items": items_payload
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"查询失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>/match-suppliers', methods=['POST', 'OPTIONS'])
def match_suppliers(rfq_id):
    """
    为RFQ匹配供应商（按品类）
    Returns:
    {
        "routes": {
            "category_name": [supplier_id, ...]
        }
    }
    """
    if request.method == 'OPTIONS':
        return "", 204

    try:
        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": "RFQ不存在"}), 404

        routes = rfq_service.match_suppliers_for_rfq(rfq)
        return jsonify({
            "routes": routes,
            "message": f"匹配成功，共{sum(len(v) for v in routes.values())}个供应商"
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"匹配失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>/send', methods=['POST', 'OPTIONS'])
def send_rfq(rfq_id):
    """
    发送RFQ给供应商（永久修复接入点）
    Request:
    {
        "routes": { "category_name": [supplier_id, ...] }  // 可选；不传则自动匹配
    }
    """
    if request.method == 'OPTIONS':
        return "", 204

    try:
        data = request.get_json() or {}
        routes = data.get('routes')  # None/{} 均可，None 表示自动匹配

        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": "RFQ不存在"}), 404

        if rfq.status not in ['draft', 'pending']:
            return jsonify({"error": "RFQ状态不允许发送"}), 400

        # ✅ 永久修复：匹配→落库报价行→任务→Celery→标记 sent
        result = rfq_service.send_rfq(rfq, routes=routes if routes else None)

        return jsonify({
            "message": "RFQ已发送，已生成报价行与通知任务",
            "tasks_count": len(result.get("task_ids", [])),
            "created_quotes": result.get("created_quotes", 0),
            "total_suppliers": result.get("total_suppliers", 0)
        }), 200

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({"error": f"发送失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>/manual-quote', methods=['POST', 'OPTIONS'])
def create_manual_quote(rfq_id):
    """
    手动录入报价（员工代替供应商填写报价）
    无需供应商，提交后自动创建PO，直接进入发票上传环节

    POST /api/v1/rfqs/<rfq_id>/manual-quote
    Body: {
        "quotes": [
            {
                "category": "刀具/铣削刀具",
                "supplier_name": "手动采购",  // 可选
                "items": [
                    {
                        "item_name": "铣刀",
                        "item_description": "直径10mm",
                        "quantity_requested": 100,
                        "unit": "个",
                        "unit_price": 45.00,
                        "subtotal": 4500.00
                    }
                ],
                "total_price": 4500.00,
                "lead_time": 7,
                "payment_terms": 90,
                "notes": "手动录入"
            }
        ]
    }

    Returns:
        {
            "success": true,
            "rfq_id": 123,
            "quotes_created": 2,
            "pos_created": 2,
            "message": "手动报价成功，已生成采购订单"
        }
    """
    if request.method == 'OPTIONS':
        return "", 204

    try:
        from models.supplier import Supplier
        from models.purchase_order import PurchaseOrder
        from datetime import timedelta

        # 验证RFQ存在
        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": f"RFQ#{rfq_id} 不存在"}), 404

        # 获取报价数据
        data = request.get_json() or {}
        quotes_data = data.get('quotes', [])

        if not quotes_data:
            return jsonify({"error": "请至少提供一个报价"}), 400

        # 获取或创建"手动采购"供应商
        manual_supplier = Supplier.query.filter_by(company_name='手动采购').first()
        if not manual_supplier:
            manual_supplier = Supplier(
                company_name='手动采购',
                contact_name='系统',
                contact_email='manual@system.local',
                contact_phone='000-0000-0000',
                status='approved',
                categories='',
                created_at=datetime.utcnow()
            )
            db.session.add(manual_supplier)
            db.session.flush()

        created_quotes = []
        created_pos = []

        for quote_data in quotes_data:
            supplier_name = quote_data.get('supplier_name', '手动采购')
            category = quote_data.get('category', '未分类')
            items = quote_data.get('items', [])
            total_price = quote_data.get('total_price', 0)
            lead_time = quote_data.get('lead_time', 7)
            payment_terms = quote_data.get('payment_terms', 90)
            notes = quote_data.get('notes', '手动录入')

            if not items:
                return jsonify({"error": "每个报价必须包含至少一个物料"}), 400

            # 检查是否已存在该品类的报价
            existing_quote = SupplierQuote.query.filter_by(
                rfq_id=rfq_id,
                supplier_id=manual_supplier.id,
                category=category
            ).first()

            if existing_quote:
                # 更新已存在的报价
                existing_quote.total_price = total_price
                existing_quote.supplier_name = supplier_name
                existing_quote.lead_time = lead_time
                existing_quote.payment_terms = payment_terms
                existing_quote.status = 'awarded'  # 直接标记为已中标
                existing_quote.responded_at = datetime.utcnow()
                existing_quote.quote_json = json.dumps({
                    "items": items,
                    "notes": notes,
                    "manual_entry": True
                }, ensure_ascii=False)
                quote = existing_quote
            else:
                # 创建新报价
                quote = SupplierQuote(
                    rfq_id=rfq_id,
                    supplier_id=manual_supplier.id,
                    supplier_name=supplier_name,
                    category=category,
                    status='awarded',  # 直接标记为已中标（跳过选标）
                    total_price=total_price,
                    lead_time=lead_time,
                    payment_terms=payment_terms,
                    quote_json=json.dumps({
                        "items": items,
                        "notes": notes,
                        "manual_entry": True
                    }, ensure_ascii=False),
                    created_at=datetime.utcnow(),
                    responded_at=datetime.utcnow()
                )
                db.session.add(quote)
                db.session.flush()

            created_quotes.append(quote.id)

            # 自动创建PO（跳过选标环节）
            # 检查是否已有PO
            existing_po = PurchaseOrder.query.filter_by(
                rfq_id=rfq_id,
                quote_id=quote.id
            ).first()

            if not existing_po:
                po = PurchaseOrder(
                    po_number=PurchaseOrder.generate_po_number(),
                    rfq_id=rfq_id,
                    quote_id=quote.id,
                    supplier_id=manual_supplier.id,
                    supplier_name=supplier_name,
                    total_price=total_price,
                    lead_time=lead_time,
                    quote_data=quote.quote_json,
                    status='confirmed',  # 直接确认
                    confirmed_at=datetime.utcnow(),
                    invoice_due_date=datetime.utcnow() + timedelta(days=7),
                    invoice_uploaded=False
                )
                db.session.add(po)
                db.session.flush()
                created_pos.append({
                    'po_number': po.po_number,
                    'supplier_name': supplier_name,
                    'total_price': float(total_price)
                })

        # 更新RFQ状态为已创建PO
        rfq.status = 'po_created'

        db.session.commit()

        return jsonify({
            "success": True,
            "rfq_id": rfq_id,
            "quotes_created": len(created_quotes),
            "quote_ids": created_quotes,
            "pos_created": created_pos,
            "message": f"手动报价成功！已创建 {len(created_pos)} 个采购订单，等待发票上传"
        }), 200

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({"error": f"手动报价失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>/quotes', methods=['GET', 'OPTIONS'])
def get_rfq_quotes(rfq_id):
    """获取RFQ的所有报价"""
    if request.method == 'OPTIONS':
        return "", 204

    try:
        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": "RFQ不存在"}), 404

        quotes = SupplierQuote.query.filter_by(rfq_id=rfq_id).all()

        return jsonify({
            "rfq_id": rfq_id,
            "quotes": [{
                "id": q.id,
                "supplier_id": q.supplier_id,
                "supplier_name": q.supplier.company_name if q.supplier else q.supplier_name,
                "status": q.status,
                # ↓ 保留你原来的返回结构，同时兼容新字段
                "item_name": getattr(q, "item_name", None),
                "item_description": getattr(q, "item_description", None),
                "quantity_requested": getattr(q, "quantity_requested", None),
                "unit": getattr(q, "unit", None),
                "total_price": getattr(q, "total_price", None),
                "lead_time": getattr(q, "lead_time", None),
                "quote_data": json.loads(q.quote_json) if q.quote_json else None,
                "created_at": iso(q.created_at),
                "responded_at": iso(q.responded_at)
            } for q in quotes]
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"查询失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>/status', methods=['GET', 'OPTIONS'])
def get_rfq_status(rfq_id):
    """获取RFQ发送状态（包含通知任务进度）"""
    if request.method == 'OPTIONS':
        return "", 204

    try:
        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": "RFQ不存在"}), 404

        # 统计任务状态
        total_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq_id).count()
        sent_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq_id, status='sent').count()
        failed_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq_id, status='failed').count()
        pending_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq_id, status='pending').count()

        # 统计报价
        quotes_received = SupplierQuote.query.filter_by(
            rfq_id=rfq_id,
            status='received'
        ).count()

        return jsonify({
            "rfq_id": rfq_id,
            "rfq_status": rfq.status,
            "tasks": {
                "total": total_tasks,
                "sent": sent_tasks,
                "pending": pending_tasks,
                "failed": failed_tasks
            },
            "quotes_received": quotes_received,
            "progress": f"{sent_tasks}/{total_tasks}"
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"查询失败: {str(e)}"}), 500


@bp.route('/outbox', methods=['GET', 'OPTIONS'])
def list_outbox():
    """RFQ 发件箱汇总视图"""
    if request.method == 'OPTIONS':
        return "", 204
    try:
        rfqs = RFQ.query.filter(RFQ.status.in_(['sent', 'pending']))\
            .order_by(RFQ.created_at.desc()).all()

        def iso(dt): return dt.isoformat(timespec='seconds') if dt else None

        items = []
        for rfq in rfqs:
            cats = list({(it.category or '').strip() for it in (rfq.items or []) if (it.category or '').strip()})
            total_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq.id).count()
            sent_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq.id, status='sent').count()
            failed_tasks = RFQNotificationTask.query.filter_by(rfq_id=rfq.id, status='failed').count()
            quote_count = SupplierQuote.query.filter_by(
                rfq_id=rfq.id, status='received'
            ).distinct(SupplierQuote.supplier_id).count()
            items.append({
                "id": rfq.id,
                "rfqNumber": getattr(rfq, "rfq_number", None) or f"RFQ-{rfq.id}",
                "prNumber": getattr(rfq.pr, "pr_number", None) if getattr(rfq, "pr", None) else None,
                "status": rfq.status,  # 添加状态字段
                "created_at": iso(getattr(rfq, "created_at", None)),  # snake_case版本
                "createdAt": iso(getattr(rfq, "created_at", None)),
                "sentAt": iso(getattr(rfq, "sent_at", None)),
                "itemsCount": len(rfq.items or []),
                "categories": cats,
                "categoriesCount": len(cats),
                "supplierCount": RFQNotificationTask.query.filter_by(rfq_id=rfq.id)\
                    .distinct(RFQNotificationTask.supplier_id).count(),
                "taskTotal": total_tasks,
                "taskSent": sent_tasks,
                "taskFailed": failed_tasks,
                "quoteCount": quote_count,
            })
        return jsonify({"items": items}), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": f"查询失败: {str(e)}"}), 500


@bp.route('/<int:rfq_id>/create-po', methods=['POST', 'OPTIONS'])
def create_po_from_rfq(rfq_id):
    """
    从RFQ创建采购订单（选中标）

    POST /api/v1/rfqs/<rfq_id>/create-po
    Body: {
        "selected_quotes": [1, 2, 3]  # 选中的报价ID列表
    }

    Returns:
        {
            "success": true,
            "rfq_id": 123,
            "selected_quotes": 3,
            "pos_created": [...],  # 创建的PO列表
            "message": "成功创建 3 个采购订单"
        }
    """
    if request.method == 'OPTIONS':
        return jsonify({}), 200

    try:
        from models.purchase_order import PurchaseOrder
        from datetime import timedelta

        # 获取请求数据
        data = request.get_json() or {}
        selected_quote_ids = data.get('selected_quotes', [])

        if not selected_quote_ids:
            return jsonify({"error": "请选择至少一个报价"}), 400

        # 验证RFQ存在
        rfq = RFQ.query.get(rfq_id)
        if not rfq:
            return jsonify({"error": f"RFQ#{rfq_id} 不存在"}), 404

        # 验证所有报价都属于这个RFQ
        quotes = SupplierQuote.query.filter(
            SupplierQuote.id.in_(selected_quote_ids),
            SupplierQuote.rfq_id == rfq_id
        ).all()

        if len(quotes) != len(selected_quote_ids):
            return jsonify({"error": "部分报价不属于该RFQ"}), 400

        # 验证所有报价都已提交
        pending_quotes = [q for q in quotes if q.status == 'pending']
        if pending_quotes:
            return jsonify({
                "error": f"有 {len(pending_quotes)} 个报价尚未提交"
            }), 400

        # 创建PO记录
        pos_created = []
        for quote in quotes:
            # 标记报价为"已中标"
            quote.status = 'awarded'

            # 创建PO
            po = PurchaseOrder(
                po_number=PurchaseOrder.generate_po_number(),
                rfq_id=rfq_id,
                quote_id=quote.id,
                supplier_id=quote.supplier_id,
                supplier_name=quote.supplier.company_name if quote.supplier else quote.supplier_name,
                total_price=quote.total_price or 0,
                lead_time=quote.lead_time,
                quote_data=quote.quote_json,
                status='confirmed',  # 修复：选标即确认，供应商可立即看到待上传发票
                confirmed_at=datetime.utcnow(),
                invoice_due_date=datetime.utcnow() + timedelta(days=7),  # 7天后到期
                invoice_uploaded=False
            )

            db.session.add(po)
            pos_created.append({
                'po_number': po.po_number,
                'supplier_name': po.supplier_name,
                'total_price': float(po.total_price),
                'invoice_due_date': po.invoice_due_date.isoformat() if po.invoice_due_date else None
            })

        # 更新RFQ状态
        rfq.status = 'po_created'

        db.session.commit()

        # 🔔 发送PO创建通知给供应商
        from services.notification_service import NotificationService
        for quote in quotes:
            if quote.supplier:
                # 找到对应的PO（通过quote_id）
                po = PurchaseOrder.query.filter_by(quote_id=quote.id).first()
                if po:
                    NotificationService.notify_po_created(po, quote.supplier)

        return jsonify({
            "success": True,
            "rfq_id": rfq_id,
            "selected_quotes": len(quotes),
            "pos_created": pos_created,
            "message": f"成功创建 {len(quotes)} 个采购订单，发票需在7天内上传，已通知供应商"
        }), 200

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({"error": f"创建采购订单失败: {str(e)}"}), 500
