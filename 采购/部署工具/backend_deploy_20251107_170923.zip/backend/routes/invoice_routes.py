# routes/invoice_routes.py
# -*- coding: utf-8 -*-
"""
发票管理路由 - 员工端和供应商端
"""
from flask import Blueprint, request, jsonify
from extensions import db
from models.invoice import Invoice
from models.purchase_order import PurchaseOrder
from models.supplier import Supplier
from datetime import datetime, timedelta
from sqlalchemy import or_, and_, func
import traceback

URL_PREFIX = '/api/v1/invoices'

bp = Blueprint('invoice', __name__)


@bp.before_request
def handle_preflight():
    """处理CORS预检请求"""
    if request.method == 'OPTIONS':
        return '', 200


def iso(dt):
    """日期序列化"""
    return dt.isoformat(timespec='seconds') if dt else None


# ============ 员工端API ============

@bp.route('', methods=['GET', 'OPTIONS'])
def get_invoices():
    """
    获取发票列表（员工端）

    查询参数：
    - page: 页码
    - per_page: 每页数量
    - status: 状态筛选 (pending/approved/rejected)
    - supplier_id: 供应商筛选
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 100, type=int)
        status = request.args.get('status')
        supplier_id = request.args.get('supplier_id', type=int)

        query = Invoice.query

        # 筛选条件
        if status:
            query = query.filter_by(status=status)
        if supplier_id:
            query = query.filter_by(supplier_id=supplier_id)

        # 分页
        query = query.order_by(Invoice.created_at.desc())
        paginated = query.paginate(page=page, per_page=per_page, error_out=False)

        invoices = []
        for inv in paginated.items:
            invoice_dict = {
                'id': inv.id,
                'invoice_number': inv.invoice_number,
                'po_id': inv.po_id,
                'supplier_id': inv.supplier_id,
                'supplier_name': inv.supplier.company_name if inv.supplier else None,
                'po_number': inv.po.po_number if inv.po else None,
                'amount': float(inv.amount) if inv.amount else 0,
                'currency': inv.currency,
                'invoice_date': iso(inv.invoice_date),
                'file_url': inv.file_url,
                'file_name': inv.file_name,
                'status': inv.status,
                'approval_notes': inv.approval_notes,
                'created_at': iso(inv.created_at),
                'uploaded_at': iso(inv.uploaded_at),
                'approved_at': iso(inv.approved_at),
                'description': inv.description,
            }
            invoices.append(invoice_dict)

        return jsonify({
            'total': paginated.total,
            'pages': paginated.pages,
            'current_page': page,
            'per_page': per_page,
            'invoices': invoices
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取发票列表失败: {str(e)}'}), 500


@bp.route('/overdue', methods=['GET', 'OPTIONS'])
def get_overdue_invoices():
    """
    获取超期发票列表（未在7天内上传的PO）

    返回所有超过invoice_due_date但未上传发票的PO
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        now = datetime.utcnow()

        # 查询超期的PO（invoice_due_date < now 且 invoice_uploaded = False）
        overdue_pos = PurchaseOrder.query.filter(
            and_(
                PurchaseOrder.invoice_due_date < now,
                PurchaseOrder.invoice_uploaded == False,
                PurchaseOrder.status != 'cancelled'
            )
        ).order_by(PurchaseOrder.invoice_due_date.asc()).all()

        result = []
        for po in overdue_pos:
            days_overdue = (now - po.invoice_due_date).days
            result.append({
                'po_id': po.id,
                'po_number': po.po_number,
                'supplier_id': po.supplier_id,
                'supplier_name': po.supplier_name,
                'total_price': float(po.total_price),
                'status': po.status,
                'confirmed_at': iso(po.confirmed_at),
                'invoice_due_date': iso(po.invoice_due_date),
                'days_overdue': days_overdue,
            })

        return jsonify({
            'count': len(result),
            'overdue_pos': result
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取超期发票失败: {str(e)}'}), 500


@bp.route('/stats', methods=['GET', 'OPTIONS'])
def get_invoice_stats():
    """
    获取发票统计信息（员工端）

    返回：
    - total: 总数
    - pending: 待审核
    - approved: 已批准
    - rejected: 已拒绝
    - overdue_count: 未提交超期数量
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        now = datetime.utcnow()

        # 发票统计
        total = Invoice.query.count()
        pending = Invoice.query.filter_by(status='pending').count()
        approved = Invoice.query.filter_by(status='approved').count()
        rejected = Invoice.query.filter_by(status='rejected').count()

        # 超期未提交统计
        overdue_count = PurchaseOrder.query.filter(
            and_(
                PurchaseOrder.invoice_due_date < now,
                PurchaseOrder.invoice_uploaded == False,
                PurchaseOrder.status != 'cancelled'
            )
        ).count()

        return jsonify({
            'total': total,
            'pending': pending,
            'approved': approved,
            'rejected': rejected,
            'overdue_count': overdue_count
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取统计失败: {str(e)}'}), 500


@bp.route('/<int:invoice_id>', methods=['GET', 'OPTIONS'])
def get_invoice_detail(invoice_id):
    """获取发票详情"""
    if request.method == 'OPTIONS':
        return '', 200

    try:
        invoice = Invoice.query.get(invoice_id)
        if not invoice:
            return jsonify({'error': '发票不存在'}), 404

        return jsonify(invoice.to_dict()), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取发票详情失败: {str(e)}'}), 500


@bp.route('/<int:invoice_id>/approve', methods=['POST', 'OPTIONS'])
def approve_invoice(invoice_id):
    """
    批准发票

    请求体：
    {
        "approval_notes": "审批意见（可选）"
    }
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        data = request.get_json() or {}
        invoice = Invoice.query.get(invoice_id)

        if not invoice:
            return jsonify({'error': '发票不存在'}), 404

        if invoice.status != 'pending':
            return jsonify({'error': '只能审批待审核的发票'}), 400

        # 更新发票状态
        invoice.status = 'approved'
        invoice.approval_notes = data.get('approval_notes', '')
        invoice.approved_at = datetime.utcnow()
        invoice.approved_by = int(request.headers.get('User-ID', 0))

        db.session.commit()

        # 🔔 发送发票审批通过通知给供应商
        from services.notification_service import NotificationService
        if invoice.supplier:
            NotificationService.notify_invoice_approved(invoice, invoice.supplier)

        return jsonify({
            'success': True,
            'message': '发票已批准，已通知供应商',
            'invoice': invoice.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'error': f'批准发票失败: {str(e)}'}), 500


@bp.route('/<int:invoice_id>/reject', methods=['POST', 'OPTIONS'])
def reject_invoice(invoice_id):
    """
    拒绝发票

    请求体：
    {
        "approval_notes": "拒绝原因（必填）"
    }
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        data = request.get_json() or {}
        approval_notes = data.get('approval_notes', '').strip()

        if not approval_notes:
            return jsonify({'error': '请填写拒绝原因'}), 400

        invoice = Invoice.query.get(invoice_id)

        if not invoice:
            return jsonify({'error': '发票不存在'}), 404

        if invoice.status != 'pending':
            return jsonify({'error': '只能审批待审核的发票'}), 400

        # 更新发票状态
        invoice.status = 'rejected'
        invoice.approval_notes = approval_notes
        invoice.approved_at = datetime.utcnow()
        invoice.approved_by = int(request.headers.get('User-ID', 0))

        db.session.commit()

        # 🔔 发送发票驳回通知给供应商
        from services.notification_service import NotificationService
        if invoice.supplier:
            NotificationService.notify_invoice_rejected(invoice, invoice.supplier, approval_notes)

        return jsonify({
            'success': True,
            'message': '发票已拒绝，已通知供应商',
            'invoice': invoice.to_dict()
        }), 200

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'error': f'拒绝发票失败: {str(e)}'}), 500


# ============ 供应商端API ============

@bp.route('/supplier/pending-pos', methods=['GET', 'OPTIONS'])
def get_supplier_pending_pos():
    """
    获取供应商待上传发票的PO列表

    需要请求头：Supplier-ID (供应商ID)
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        supplier_id = request.headers.get('Supplier-ID')
        if not supplier_id:
            return jsonify({'error': '未授权'}), 401

        # 获取供应商信息
        supplier = Supplier.query.get(int(supplier_id))
        if not supplier:
            return jsonify({'error': '供应商不存在'}), 404

        now = datetime.utcnow()

        # 查询该供应商的待上传发票的PO
        # 只包括已确认(confirmed)和已收货(received)的订单
        pending_pos = PurchaseOrder.query.filter(
            and_(
                PurchaseOrder.supplier_id == supplier.id,
                PurchaseOrder.invoice_uploaded == False,
                PurchaseOrder.status.in_(['confirmed', 'received'])
            )
        ).order_by(PurchaseOrder.confirmed_at.desc()).all()

        result = []
        for po in pending_pos:
            days_remaining = (po.invoice_due_date - now).days if po.invoice_due_date else None
            is_overdue = days_remaining is not None and days_remaining < 0

            result.append({
                'po_id': po.id,
                'po_number': po.po_number,
                'total_price': float(po.total_price),
                'status': po.status,
                'confirmed_at': iso(po.confirmed_at),
                'invoice_due_date': iso(po.invoice_due_date),
                'days_remaining': days_remaining,
                'is_overdue': is_overdue,
                'urgency_level': 'overdue' if is_overdue else (
                    'critical' if days_remaining <= 2 else (
                        'warning' if days_remaining <= 5 else 'normal'
                    )
                ) if days_remaining is not None else 'normal'
            })

        return jsonify({
            'count': len(result),
            'pending_pos': result
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取待上传PO失败: {str(e)}'}), 500


@bp.route('/supplier/upload', methods=['POST', 'OPTIONS'])
def upload_invoice():
    """
    供应商上传发票

    请求体：
    {
        "po_id": 123,
        "invoice_number": "INV-20250101-001",
        "invoice_date": "2025-01-01",
        "amount": 5000.00,
        "currency": "CNY",
        "file_url": "/uploads/invoice_xxx.pdf",
        "file_name": "发票.pdf",
        "file_type": "application/pdf",
        "file_size": "1.5MB",
        "description": "备注"
    }
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        supplier_id = request.headers.get('Supplier-ID')
        if not supplier_id:
            return jsonify({'error': '未授权'}), 401

        # 获取供应商信息
        supplier = Supplier.query.get(int(supplier_id))
        if not supplier:
            return jsonify({'error': '供应商不存在'}), 404

        data = request.get_json() or {}

        # 验证必填字段
        required_fields = ['po_id', 'invoice_number', 'amount', 'file_url']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'缺少必填字段: {field}'}), 400

        # 验证PO
        po = PurchaseOrder.query.get(data['po_id'])
        if not po:
            return jsonify({'error': 'PO不存在'}), 404

        if po.supplier_id != supplier.id:
            return jsonify({'error': '无权为此PO上传发票'}), 403

        if po.invoice_uploaded:
            return jsonify({'error': '此PO已上传发票'}), 400

        # 检查发票号是否重复
        existing = Invoice.query.filter_by(invoice_number=data['invoice_number']).first()
        if existing:
            return jsonify({'error': '发票号已存在'}), 400

        # 创建发票记录
        invoice = Invoice(
            supplier_id=supplier.id,
            po_id=po.id,
            quote_id=po.quote_id,
            invoice_number=data['invoice_number'],
            invoice_date=datetime.fromisoformat(data['invoice_date']) if data.get('invoice_date') else None,
            amount=data['amount'],
            currency=data.get('currency', 'CNY'),
            file_url=data['file_url'],
            file_name=data.get('file_name'),
            file_type=data.get('file_type'),
            file_size=data.get('file_size'),
            description=data.get('description'),
            status='pending',
            uploaded_at=datetime.utcnow()
        )

        # 更新PO状态
        po.invoice_uploaded = True

        db.session.add(invoice)
        db.session.commit()

        return jsonify({
            'success': True,
            'message': '发票上传成功',
            'invoice': invoice.to_dict()
        }), 201

    except Exception as e:
        db.session.rollback()
        traceback.print_exc()
        return jsonify({'error': f'上传发票失败: {str(e)}'}), 500


@bp.route('/supplier/my-invoices', methods=['GET', 'OPTIONS'])
def get_supplier_invoices():
    """
    获取供应商自己的发票列表

    需要请求头：Supplier-ID (供应商ID)
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        supplier_id = request.headers.get('Supplier-ID')
        if not supplier_id:
            return jsonify({'error': '未授权'}), 401

        # 获取供应商信息
        supplier = Supplier.query.get(int(supplier_id))
        if not supplier:
            return jsonify({'error': '供应商不存在'}), 404

        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 100, type=int)
        status = request.args.get('status')

        query = Invoice.query.filter_by(supplier_id=supplier.id)

        if status:
            query = query.filter_by(status=status)

        query = query.order_by(Invoice.created_at.desc())
        paginated = query.paginate(page=page, per_page=per_page, error_out=False)

        invoices = []
        for inv in paginated.items:
            invoices.append({
                'id': inv.id,
                'invoice_number': inv.invoice_number,
                'po_id': inv.po_id,
                'po_number': inv.po.po_number if inv.po else None,
                'amount': float(inv.amount) if inv.amount else 0,
                'currency': inv.currency,
                'invoice_date': iso(inv.invoice_date),
                'file_url': inv.file_url,
                'file_name': inv.file_name,
                'status': inv.status,
                'approval_notes': inv.approval_notes,
                'created_at': iso(inv.created_at),
                'uploaded_at': iso(inv.uploaded_at),
                'approved_at': iso(inv.approved_at),
            })

        return jsonify({
            'total': paginated.total,
            'pages': paginated.pages,
            'current_page': page,
            'per_page': per_page,
            'invoices': invoices
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取发票列表失败: {str(e)}'}), 500


@bp.route('/supplier/stats', methods=['GET', 'OPTIONS'])
def get_supplier_invoice_stats():
    """
    获取供应商发票统计

    需要请求头：Supplier-ID (供应商ID)
    """
    if request.method == 'OPTIONS':
        return '', 200

    try:
        supplier_id = request.headers.get('Supplier-ID')
        if not supplier_id:
            return jsonify({'error': '未授权'}), 401

        # 获取供应商信息
        supplier = Supplier.query.get(int(supplier_id))
        if not supplier:
            return jsonify({'error': '供应商不存在'}), 404

        now = datetime.utcnow()

        # 发票统计
        total = Invoice.query.filter_by(supplier_id=supplier.id).count()
        pending = Invoice.query.filter_by(supplier_id=supplier.id, status='pending').count()
        approved = Invoice.query.filter_by(supplier_id=supplier.id, status='approved').count()
        rejected = Invoice.query.filter_by(supplier_id=supplier.id, status='rejected').count()

        # 超期未提交统计
        overdue_count = PurchaseOrder.query.filter(
            and_(
                PurchaseOrder.supplier_id == supplier.id,
                PurchaseOrder.invoice_due_date < now,
                PurchaseOrder.invoice_uploaded == False,
                PurchaseOrder.status != 'cancelled'
            )
        ).count()

        return jsonify({
            'total': total,
            'pending': pending,
            'approved': approved,
            'rejected': rejected,
            'overdue_count': overdue_count
        }), 200

    except Exception as e:
        traceback.print_exc()
        return jsonify({'error': f'获取统计失败: {str(e)}'}), 500
