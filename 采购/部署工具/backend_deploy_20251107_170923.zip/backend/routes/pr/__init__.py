# routes/pr/__init__.py
# PR模块蓝图注册

from flask import Blueprint

def register_pr_routes(app):
    """
    在 app.py 中调用此函数注册所有PR路由
    
    使用方式：
        from routes.pr import register_pr_routes
        register_pr_routes(app)
    """
    from .create import bp as create_bp
    from .query import bp as query_bp
    from .approval import bp as approval_bp
    from .search import bp as search_bp
    from .statistics import bp as statistics_bp
    
    # 注册所有蓝图，使用统一的url前缀
    app.register_blueprint(create_bp, url_prefix='/api/v1/pr')
    app.register_blueprint(query_bp, url_prefix='/api/v1/pr')
    app.register_blueprint(approval_bp, url_prefix='/api/v1/pr')
    app.register_blueprint(search_bp, url_prefix='/api/v1/pr')
    app.register_blueprint(statistics_bp, url_prefix='/api/v1/pr')
    
    # 注册别名路由：支持 POST /api/v1/prs（前端期望的端点）
    @app.route('/api/v1/prs', methods=['POST', 'OPTIONS'])
    def create_pr_alias():
        """别名路由：POST /api/v1/prs -> POST /api/v1/pr/prs"""
        from .create import create_pr
        return create_pr()