# routes/pr/approval.py
# 审批相关接口（批准/驳回）

from flask import Blueprint, request, jsonify
from models.pr import PR
from extensions import db
import traceback
from .common import zh_status

bp = Blueprint('pr_approval', __name__)

@bp.route('/<int:id>/<string:action>', methods=['POST', 'OPTIONS'])
def approve_or_reject(id, action):
    """
    审批操作：通过或驳回
    
    参数：
    - id: PR ID
    - action: "approve" 或 "reject"
    - body (reject时): {"reason": "驳回原因"}
    
    Response:
    {
        "message": "申请已通过/驳回",
        "status": "已批准/已驳回",
        "id": 1,
        "prNumber": "PR-2025-001",
        "rfq_auto_created": true/false,
        "rfq_id": 123 或 null,
        "rfq_message": "已自动创建RFQ（draft状态）",
        "rfq_warning": "自动创建RFQ失败: ..."
    }
    """
    if request.method == 'OPTIONS':
        return "", 204
    
    try:
        pr = PR.query.get(id)
        if not pr:
            return jsonify({"error": "申请不存在"}), 404

        rfq_created = False
        rfq_id = None
        rfq_error = None

        if action == "approve":
            pr.status = "approved"
            for item in pr.items:
                item.status = "approved"

            # 自动创建RFQ
            try:
                from services.rfq_service import RFQService
                rfq_service = RFQService()

                rfq = rfq_service.create_rfq_from_pr(
                    pr=pr,
                    user_id=pr.owner_id,
                    note=f"自动从PR#{pr.id}创建"
                )

                rfq_created = True
                rfq_id = rfq.id
                print(f"✅ 自动创建RFQ#{rfq.id}从PR#{pr.id}")

            except Exception as e:
                rfq_created = False
                rfq_id = None
                rfq_error = str(e)
                print(f"⚠️  自动创建RFQ失败，PR#{pr.id}将保持draft RFQ状态: {e}")
                traceback.print_exc()

            # 发送审批通过通知（含企业微信）
            try:
                from services.notification_service import NotificationService
                NotificationService.notify_pr_approved_to_owner(pr)
            except Exception as e:
                print(f"⚠️  发送审批通过通知失败: {e}")

        elif action == "reject":
            pr.status = "rejected"

            # 保存驳回原因
            reason = request.json.get('reason', '') if request.json else ''
            if reason and hasattr(pr, 'reject_reason'):
                pr.reject_reason = reason

            for item in pr.items:
                item.status = "rejected"
                if reason and hasattr(item, 'reject_reason'):
                    item.reject_reason = reason

            # 发送驳回通知（含企业微信）
            try:
                from services.notification_service import NotificationService
                NotificationService.notify_pr_rejected_to_owner(pr, reason)
            except Exception as e:
                print(f"⚠️  发送驳回通知失败: {e}")
        else:
            return jsonify({"error": "无效的操作"}), 400

        db.session.commit()
        
        # 返回详细响应
        response = {
            "message": f"申请已{ '通过' if action=='approve' else '驳回' }",
            "status": zh_status(pr.status),
            "status_code": pr.status,
            "id": pr.id,
            "prNumber": pr.pr_number
        }
        
        if rfq_created:
            response["rfq_auto_created"] = True
            response["rfq_id"] = rfq_id
            response["rfq_message"] = "已自动创建RFQ（draft状态）"
        else:
            response["rfq_auto_created"] = False
            if rfq_error:
                response["rfq_warning"] = f"自动创建RFQ失败: {rfq_error}，请手动创建"
        
        return jsonify(response), 200

    except Exception as e:
        db.session.rollback()
        print(f"审批操作错误: {str(e)}")
        traceback.print_exc()
        return jsonify({"error": f"操作失败: {str(e)}"}), 500