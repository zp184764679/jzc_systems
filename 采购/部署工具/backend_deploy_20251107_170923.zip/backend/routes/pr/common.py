# routes/pr/common.py
# PR模块公共工具函数

_STATUS_MAP_ZH = {
    "submitted": "待审批",
    "approved": "已批准",
    "rejected": "已驳回",
    "draft": "草稿",
}

_URGENCY_MAP_ZH = {
    "high": "高",
    "medium": "中",
    "low": "低",
    "normal": "中",
}

def zh_status(s):
    """将英文状态转为中文"""
    return _STATUS_MAP_ZH.get(s, s or "-")

def zh_urgency(u):
    """将英文紧急程度转为中文"""
    return _URGENCY_MAP_ZH.get(u, u or "-")

def iso(dt):
    """将datetime转为ISO格式字符串"""
    return dt.isoformat(timespec='seconds') if dt else None

def _normalize_urgency_input(u: str) -> str:
    """
    入库前的容错：支持中文传参（高/中/低），以及 high/medium/low/normal。
    存库仍用英文，前端展示走 zh_urgency。
    """
    if not u:
        return "medium"
    u = str(u).strip().lower()
    cn_map = {"高": "high", "中": "medium", "低": "low", "正常": "medium"}
    if u in ("high", "medium", "low", "normal"):
        return u
    return cn_map.get(u, "medium")